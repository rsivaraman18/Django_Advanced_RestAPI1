-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 09, 2024 at 06:24 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rest_26_movies`
--

-- --------------------------------------------------------

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
CREATE TABLE IF NOT EXISTS `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `authtoken_token`
--

INSERT INTO `authtoken_token` (`key`, `created`, `user_id`) VALUES
('3c2b2d93fbcdb84ba9d4910d255dc587cb7f234e', '2024-09-05 08:47:53.873519', 1),
('87a3efe3abeb1afd3f8ad47b240ff984949bcb79', '2024-09-06 10:47:24.094470', 2),
('444cbb6c568abf4aa3b00f0119ebb8b44d081207', '2024-09-06 10:47:46.316610', 3),
('784b9b804777a8e93118d0e0d443d48022829a55', '2024-09-06 10:47:57.887599', 4),
('7ca66c302a67cbad61709d4273dc28166967ca68', '2024-09-06 10:48:08.546749', 5),
('bca68da31a9081e7554fdfcf02ba36b6509bd3a5', '2024-09-06 10:48:18.792969', 6);

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add my stream platform', 7, 'add_mystreamplatform'),
(26, 'Can change my stream platform', 7, 'change_mystreamplatform'),
(27, 'Can delete my stream platform', 7, 'delete_mystreamplatform'),
(28, 'Can view my stream platform', 7, 'view_mystreamplatform'),
(29, 'Can add my watchlist', 8, 'add_mywatchlist'),
(30, 'Can change my watchlist', 8, 'change_mywatchlist'),
(31, 'Can delete my watchlist', 8, 'delete_mywatchlist'),
(32, 'Can view my watchlist', 8, 'view_mywatchlist'),
(33, 'Can add my review', 9, 'add_myreview'),
(34, 'Can change my review', 9, 'change_myreview'),
(35, 'Can delete my review', 9, 'delete_myreview'),
(36, 'Can view my review', 9, 'view_myreview'),
(37, 'Can add Token', 10, 'add_token'),
(38, 'Can change Token', 10, 'change_token'),
(39, 'Can delete Token', 10, 'delete_token'),
(40, 'Can view Token', 10, 'view_token'),
(41, 'Can add Token', 11, 'add_tokenproxy'),
(42, 'Can change Token', 11, 'change_tokenproxy'),
(43, 'Can delete Token', 11, 'delete_tokenproxy'),
(44, 'Can view Token', 11, 'view_tokenproxy');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$600000$HfPA6p7bq5a7XFdJzkzRYJ$Nww4rm9wYnokH50cHfjqxFc21LB48VER3A52UUWbios=', '2024-09-06 10:37:51.472362', 1, 'siva', '', '', '', 1, 1, '2024-09-05 08:47:53.316616'),
(2, 'pbkdf2_sha256$600000$QU0E2HFz7fIgsEWo30pf80$7SwdTEWJx9SYQqUP9wvSNg3k/KGn8ORdszyxvbUbK4g=', NULL, 0, 'demo1', '', '', 'demo1@gmail.com', 0, 1, '2024-09-06 10:47:23.498572'),
(3, 'pbkdf2_sha256$600000$SxKNLGHwTLftUlRIACtfzK$zdd7NinvtRl2N4QeB7GTnW4XvCsSfL8NIu+3w3xlWbE=', NULL, 0, 'demo2', '', '', 'demo2@gmail.com', 0, 1, '2024-09-06 10:47:45.716738'),
(4, 'pbkdf2_sha256$600000$k4vITRuveZXjFepWxwGBL4$sjYs52Cfr+mKJitaeZguC18DPHMACjJgsOJl2oEx0Yk=', NULL, 0, 'demo3', '', '', 'demo3@gmail.com', 0, 1, '2024-09-06 10:47:57.303700'),
(5, 'pbkdf2_sha256$600000$LhRcF4bJzmV5bud2xW6PC7$SHXJjdo8Jdn2IP7qvm51hTIBrA1Klj/Vb3mTaj74tqA=', NULL, 0, 'demo4', '', '', 'demo4@gmail.com', 0, 1, '2024-09-06 10:48:07.953850'),
(6, 'pbkdf2_sha256$600000$DEtvAqO0QcFmePiJgxSKGD$H/N2clOoC0ai3V3GObFn/wvvmWobzuo5AlCsuMS/IOA=', NULL, 0, 'demo5', '', '', 'demo5@gmail.com', 0, 1, '2024-09-06 10:48:18.218070');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2024-09-05 08:48:32.792811', '1', 'Youtube', 1, '[{\"added\": {}}]', 7, 1),
(2, '2024-09-05 08:48:39.881535', '2', 'Netflix', 1, '[{\"added\": {}}]', 7, 1),
(3, '2024-09-05 08:48:46.923305', '3', 'Spotify', 1, '[{\"added\": {}}]', 7, 1),
(4, '2024-09-05 08:48:59.751077', '1', 'Jailor', 1, '[{\"added\": {}}]', 8, 1),
(5, '2024-09-05 08:49:13.108808', '2', 'Vikram', 1, '[{\"added\": {}}]', 8, 1),
(6, '2024-09-05 08:49:23.539945', '1', ' Jailor  3 star | siva ', 1, '[{\"added\": {}}]', 9, 1),
(7, '2024-09-05 08:49:32.433400', '2', ' Vikram  4 star | siva ', 1, '[{\"added\": {}}]', 9, 1),
(8, '2024-09-06 10:48:58.871005', '3', 'Titanic', 1, '[{\"added\": {}}]', 8, 1),
(9, '2024-09-06 10:49:50.001130', '4', 'Dynamic Situation', 1, '[{\"added\": {}}]', 8, 1),
(10, '2024-09-06 10:50:11.430404', '5', 'Time Never Waits', 1, '[{\"added\": {}}]', 8, 1),
(11, '2024-09-06 10:50:53.391115', '6', 'Valimai', 1, '[{\"added\": {}}]', 8, 1),
(12, '2024-09-06 10:51:22.269097', '7', 'Diary', 1, '[{\"added\": {}}]', 8, 1),
(13, '2024-09-06 10:52:16.326761', '8', 'Iron', 1, '[{\"added\": {}}]', 8, 1),
(14, '2024-09-06 11:10:24.681663', '9', 'Villan', 1, '[{\"added\": {}}]', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(7, 'Movieapp', 'mystreamplatform'),
(8, 'Movieapp', 'mywatchlist'),
(9, 'Movieapp', 'myreview'),
(10, 'authtoken', 'token'),
(11, 'authtoken', 'tokenproxy');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-09-05 08:43:02.483136'),
(2, 'auth', '0001_initial', '2024-09-05 08:43:07.256307'),
(3, 'Movieapp', '0001_initial', '2024-09-05 08:43:09.698882'),
(4, 'admin', '0001_initial', '2024-09-05 08:43:10.898672'),
(5, 'admin', '0002_logentry_remove_auto_add', '2024-09-05 08:43:10.915669'),
(6, 'admin', '0003_logentry_add_action_flag_choices', '2024-09-05 08:43:10.933666'),
(7, 'contenttypes', '0002_remove_content_type_name', '2024-09-05 08:43:11.435581'),
(8, 'auth', '0002_alter_permission_name_max_length', '2024-09-05 08:43:11.646598'),
(9, 'auth', '0003_alter_user_email_max_length', '2024-09-05 08:43:11.988489'),
(10, 'auth', '0004_alter_user_username_opts', '2024-09-05 08:43:12.017478'),
(11, 'auth', '0005_alter_user_last_login_null', '2024-09-05 08:43:12.454457'),
(12, 'auth', '0006_require_contenttypes_0002', '2024-09-05 08:43:12.468401'),
(13, 'auth', '0007_alter_validators_add_error_messages', '2024-09-05 08:43:12.497395'),
(14, 'auth', '0008_alter_user_username_max_length', '2024-09-05 08:43:12.684361'),
(15, 'auth', '0009_alter_user_last_name_max_length', '2024-09-05 08:43:12.867376'),
(16, 'auth', '0010_alter_group_name_max_length', '2024-09-05 08:43:13.245267'),
(17, 'auth', '0011_update_proxy_permissions', '2024-09-05 08:43:13.275266'),
(18, 'auth', '0012_alter_user_first_name_max_length', '2024-09-05 08:43:13.476225'),
(19, 'authtoken', '0001_initial', '2024-09-05 08:43:13.744236'),
(20, 'authtoken', '0002_auto_20160226_1747', '2024-09-05 08:43:13.796198'),
(21, 'authtoken', '0003_tokenproxy', '2024-09-05 08:43:13.802170'),
(22, 'authtoken', '0004_alter_tokenproxy_options', '2024-09-05 08:43:13.810166'),
(23, 'sessions', '0001_initial', '2024-09-05 08:43:13.991135');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('iqqouq53bdadzipaquhqgc13p2yv3470', '.eJxVjDsOwjAQBe_iGll2vP5R0nMGa9dekwBypDipEHeHSCmgfTPzXiLhto5p67ykqYiz0OL0uxHmB7cdlDu22yzz3NZlIrkr8qBdXufCz8vh_h2M2MdvDWSzIut1hGACFgyV2YHR6LQdVDZOBY66mOozQiTwQAP4ypoGphrE-wPU8jfS:1sm89z:qg5_ccZerIAmCZS3WruOq06WyvDxlyLPVAnMrA5jEkA', '2024-09-19 08:48:11.732477'),
('qp0a162eo70p61r11pmdfi5um1na8bd5', '.eJxVjDsOwjAQBe_iGll2vP5R0nMGa9dekwBypDipEHeHSCmgfTPzXiLhto5p67ykqYiz0OL0uxHmB7cdlDu22yzz3NZlIrkr8qBdXufCz8vh_h2M2MdvDWSzIut1hGACFgyV2YHR6LQdVDZOBY66mOozQiTwQAP4ypoGphrE-wPU8jfS:1smWLf:O3-pXe89-pOUValB6vkH_1yoX8nalbE7JjNl35eTF2A', '2024-09-20 10:37:51.474361');

-- --------------------------------------------------------

--
-- Table structure for table `movieapp_myreview`
--

DROP TABLE IF EXISTS `movieapp_myreview`;
CREATE TABLE IF NOT EXISTS `movieapp_myreview` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rating` bigint UNSIGNED NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `created` datetime(6) NOT NULL,
  `update` datetime(6) NOT NULL,
  `reviewer_name_id` int NOT NULL,
  `watchlist_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Movieapp_myreview_reviewer_name_id_5b6c8c43` (`reviewer_name_id`),
  KEY `Movieapp_myreview_watchlist_id_2911ebf8` (`watchlist_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `movieapp_myreview`
--

INSERT INTO `movieapp_myreview` (`id`, `rating`, `description`, `active`, `created`, `update`, `reviewer_name_id`, `watchlist_id`) VALUES
(1, 3, 'Very good', 1, '2024-09-05 08:49:23.537995', '2024-09-05 08:49:23.537995', 1, 1),
(2, 4, 'Excellent', 1, '2024-09-05 08:49:32.431447', '2024-09-05 08:49:32.431447', 1, 2),
(3, 5, 'Very Good!', 1, '2024-09-06 10:55:33.817405', '2024-09-06 10:55:33.817405', 1, 3),
(4, 5, 'Very Nice!', 1, '2024-09-06 10:55:55.766594', '2024-09-06 10:55:55.766594', 1, 4),
(5, 2, 'Innovative!', 1, '2024-09-06 10:56:11.869842', '2024-09-06 10:56:11.869842', 1, 5),
(6, 4, 'Excellent!', 1, '2024-09-06 10:56:25.665398', '2024-09-06 10:56:25.665398', 1, 6),
(7, 4, 'Excellent Super!', 1, '2024-09-06 10:56:39.362020', '2024-09-06 10:56:39.362020', 1, 7),
(8, 3, 'Tremnendous Super!', 1, '2024-09-06 10:56:54.589424', '2024-09-06 10:56:54.589424', 1, 8),
(9, 3, 'great Super!', 1, '2024-09-06 10:57:25.085129', '2024-09-06 10:57:25.085129', 2, 1),
(10, 4, 'Super!', 1, '2024-09-06 10:57:43.323916', '2024-09-06 10:57:43.323916', 2, 2),
(11, 3, 'Fantastic!', 1, '2024-09-06 10:58:01.332782', '2024-09-06 10:58:01.332782', 2, 3),
(12, 3, 'Good!', 1, '2024-09-06 10:58:45.189170', '2024-09-06 10:58:45.189170', 3, 3),
(13, 1, 'Bore!', 1, '2024-09-06 10:59:06.029544', '2024-09-06 10:59:06.029544', 2, 4),
(14, 4, 'Good Enjoyed!', 1, '2024-09-06 10:59:25.144224', '2024-09-06 10:59:25.144224', 3, 4),
(15, 4, 'Smart Movie!', 1, '2024-09-06 10:59:57.418618', '2024-09-06 10:59:57.418618', 4, 4),
(16, 1, 'Mokka!', 1, '2024-09-06 11:00:23.174144', '2024-09-06 11:00:23.174144', 4, 5),
(17, 4, 'Intersting!', 1, '2024-09-06 11:00:46.146158', '2024-09-06 11:00:46.147156', 3, 5),
(18, 1, 'Supppppper!', 1, '2024-09-06 11:01:02.846305', '2024-09-06 11:01:02.846305', 2, 5),
(19, 4, 'Pleassnt!', 1, '2024-09-06 11:01:17.169767', '2024-09-06 11:01:17.169767', 3, 6),
(20, 1, 'Wow!', 1, '2024-09-06 11:01:27.079044', '2024-09-06 11:01:27.079044', 4, 6),
(21, 1, 'Best Movie!', 1, '2024-09-06 11:01:39.903871', '2024-09-06 11:01:39.903871', 2, 6),
(22, 1, 'Enjoyable!', 1, '2024-09-06 11:01:56.711898', '2024-09-06 11:01:56.711898', 4, 7),
(23, 1, 'Mind Blowing!', 1, '2024-09-06 11:02:17.802233', '2024-09-06 11:02:17.802233', 2, 7),
(24, 4, 'Good!', 1, '2024-09-06 11:02:32.602663', '2024-09-06 11:02:32.602663', 3, 7),
(25, 1, 'Worst!', 1, '2024-09-06 11:02:48.534895', '2024-09-06 11:02:48.534895', 4, 8),
(26, 2, 'Bore!', 1, '2024-09-06 11:03:05.828894', '2024-09-06 11:03:05.828894', 3, 8),
(27, 5, 'Super Extradionary!', 1, '2024-09-06 11:03:27.811073', '2024-09-06 11:03:27.811073', 2, 8),
(28, 5, 'Super Extradionary!', 1, '2024-09-06 11:05:00.605956', '2024-09-06 11:05:00.605956', 6, 8),
(29, 4, 'Super!', 1, '2024-09-06 11:05:17.721984', '2024-09-06 11:05:17.721984', 6, 7),
(30, 4, 'Super Mass!', 1, '2024-09-06 11:05:29.215986', '2024-09-06 11:05:29.215986', 6, 6),
(31, 5, 'Excellent!', 1, '2024-09-06 11:05:43.232550', '2024-09-06 11:05:43.232550', 5, 8),
(32, 5, 'Very Good!', 1, '2024-09-06 11:05:59.071815', '2024-09-06 11:05:59.071815', 5, 7),
(33, 5, 'Enjoyable!', 1, '2024-09-06 11:06:12.694435', '2024-09-06 11:06:12.694435', 5, 6),
(34, 4, 'Liked!', 1, '2024-09-06 11:06:37.761082', '2024-09-06 11:06:37.761082', 6, 5),
(35, 5, 'Out of the Box!', 1, '2024-09-06 11:06:51.758648', '2024-09-06 11:06:51.758648', 5, 5),
(36, 1, 'Worst!', 1, '2024-09-06 11:07:10.698381', '2024-09-06 11:07:10.698381', 6, 4),
(37, 2, 'Wasteeeeee!', 1, '2024-09-06 11:07:40.000301', '2024-09-06 11:07:40.000301', 5, 3),
(38, 3, 'Extradionary!', 1, '2024-09-06 11:08:01.898465', '2024-09-06 11:08:01.898465', 5, 2),
(39, 1, 'Worst!', 1, '2024-09-06 11:09:37.269950', '2024-09-06 11:09:37.269950', 6, 1),
(40, 5, 'Good!', 1, '2024-09-06 11:11:05.956494', '2024-09-06 11:11:05.956494', 1, 9),
(41, 4, 'Better!', 1, '2024-09-06 11:11:49.423992', '2024-09-06 11:11:49.423992', 3, 9);

-- --------------------------------------------------------

--
-- Table structure for table `movieapp_mystreamplatform`
--

DROP TABLE IF EXISTS `movieapp_mystreamplatform`;
CREATE TABLE IF NOT EXISTS `movieapp_mystreamplatform` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `about` varchar(150) NOT NULL,
  `website` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `movieapp_mystreamplatform`
--

INSERT INTO `movieapp_mystreamplatform` (`id`, `name`, `about`, `website`) VALUES
(1, 'Youtube', 'Free Videos', 'https://www.youtube.com/'),
(2, 'Netflix', 'Prime Video', 'https://www.netflix.com/'),
(3, 'Spotify', 'Music World', 'https://www.spotify.com/');

-- --------------------------------------------------------

--
-- Table structure for table `movieapp_mywatchlist`
--

DROP TABLE IF EXISTS `movieapp_mywatchlist`;
CREATE TABLE IF NOT EXISTS `movieapp_mywatchlist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `storyline` varchar(200) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created` date NOT NULL,
  `avg_rating` double NOT NULL,
  `number_rating` int NOT NULL,
  `platform_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Movieapp_mywatchlist_platform_id_4b65cd9f` (`platform_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `movieapp_mywatchlist`
--

INSERT INTO `movieapp_mywatchlist` (`id`, `title`, `storyline`, `active`, `created`, `avg_rating`, `number_rating`, `platform_id`) VALUES
(1, 'Jailor', 'Crime,Thriller', 1, '2024-09-05', 2, 2, 1),
(2, 'Vikram', 'Crime,Suspense', 1, '2024-09-05', 3.5, 2, 2),
(3, 'Titanic', 'Sea Voyage', 1, '2024-09-06', 3.25, 4, 1),
(4, 'Dynamic Situation', 'Suspense Life', 1, '2024-09-06', 3, 5, 2),
(5, 'Time Never Waits', 'Crime,Suspense', 1, '2024-09-06', 2.833, 6, 3),
(6, 'Valimai', 'Crime,Roberry', 1, '2024-09-06', 3.167, 6, 2),
(7, 'Diary', 'Ghost,Suspense,Horror', 1, '2024-09-06', 3.167, 6, 2),
(8, 'Iron', 'Crime,Roberry', 1, '2024-09-06', 3.5, 6, 1),
(9, 'Villan', 'Crime,Suspense', 1, '2024-09-06', 4.5, 2, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
